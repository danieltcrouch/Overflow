package Domain;

import java.util.*;

public class Deck
{
    private List<Card> cards;

    public Deck()
    {
        reset();
    }

    public void shuffle()
    {
        reset();
        Collections.shuffle( cards, new Random( System.nanoTime() ) );
    }

    private void reset()
    {
        cards = new ArrayList<>();

        for ( int i = 0; i < Card.SUIT_COUNT; i++ )
        {
            for ( int j = 0; j < Card.NUM_COUNT; j++ )
            {
                Card card = new Card( i, j );
                cards.add( card );
            }
        }
    }

    public Card deal()
    {
        Card card = cards.get( 0 );
        cards.remove( 0 );
        return card;
    }

    /***Getters and Setters***/

    public List<Card> getCards()
    {
        return cards;
    }

    private void setCards( List<Card> cards )
    {
        this.cards = cards;
    }
}