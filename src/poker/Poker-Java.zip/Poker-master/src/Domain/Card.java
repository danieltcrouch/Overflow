package Domain;

public class Card implements Comparable<Card>
{
    public static final int NUM_COUNT = 13;
    public static final int SUIT_COUNT = 4;
    public static final int BLANK = -1;

    private String face;
    private int id;
    private int suit;
    private int number;

    public Card()
    {
        setId( 0 );
        setSuit( 0 );
        setNumber( 0 );
        setFace( "00" );
    }

    public Card( Card c )
    {
        setId( c.getId() );
        setSuit( getSuitFromId( getId() ) );
        setNumber( getNumberFromId( getId() ) );
        setFace( getFaceFromId( getId() ) );
    }

    public Card( int suit, int number )
    {
        setId( number + suit * NUM_COUNT );
        setSuit( getSuitFromId( getId() ) );
        setNumber( getNumberFromId( getId() ) );
        setFace( getFaceFromId( getId() ) );
    }

    public Card( String face )
    {
        setId( getIdFromFace( face ) );
        setSuit( getSuitFromId( getId() ) );
        setNumber( getNumberFromId( getId() ) );
        setFace( face );
    }

    public static Card getBlank()
    {
        return new Card( BLANK, BLANK );
    }

    private int getSuitFromId( int id )
    {
        return id / NUM_COUNT;
    }

    private int getNumberFromId( int id )
    {
        return id - ( suit * NUM_COUNT );
    }

    private String getFaceFromId( int id )
    {
        String face;

        int number = getNumberFromId( id ) + 1;
        switch ( number )
        {
            case 13:
                face = "K";
                break;
            case 12:
                face = "Q";
                break;
            case 11:
                face = "J";
                break;
            case 10:
                face = "T";
                break;
            case 1:
                face = "A";
                break;
            default:
                face = "" + number;
        }

        switch ( getSuitFromId( id ) )
        {
            case 0:
                face += "S";
                break;
            case 1:
                face += "C";
                break;
            case 2:
                face += "D";
                break;
            case 3:
                face += "H";
                break;
            default:
                face += "0";
        }

        return face;
    }

    private int getIdFromFace( String face )
    {
        int id;

        switch ( face.charAt( 1 ) )
        {
            case 'S':
                id = 0;
                break;
            case 'C':
                id = NUM_COUNT;
                break;
            case 'D':
                id = 2 * NUM_COUNT;
                break;
            case 'H':
                id = 3 * NUM_COUNT;
                break;
            default:
                id = BLANK;
        }

        switch ( face.charAt( 0 ) )
        {
            case 'K':
                id += 12;
                break;
            case 'Q':
                id += 11;
                break;
            case 'J':
                id += 10;
                break;
            case 'T':
                id += 9;
                break;
            case 'A':
                id += 0;
                break;
            default:
                id += Character.getNumericValue( face.charAt( 0 ) ) - 1;
        }

        return id;
    }

    public int getScore()
    {
        int result = getNumber();
        if ( result == 0 )
        {
            result = NUM_COUNT; //giving Ace highest value
        }
        else if ( result == BLANK )
        {
            result = 0;
        }
        return result;
    }

    public boolean isNumberEqual( Card card )
    {
        return card != null && getNumber() == card.getNumber();
    }

    public boolean isSuiteEqual( Card card )
    {
        return card != null && getSuit() == ( card.getSuit() );
    }

    public boolean isBlank()
    {
        return getNumber() == BLANK;
    }

    /***Override***/

    @Override
    public boolean equals( Object object )
    {
        boolean result = false;
        if ( this == object )
        {
            result = true;
        }
        else if ( object instanceof Card )
        {
            Card that = (Card) object;
            if ( getId() == that.getId() )
            {
                result = true;
            }
        }

        return result;
    }

    @Override
    public int hashCode()
    {
        int result = getSuit();
        result = 31 * result + getNumber();
        return result;
    }

    @Override
    public int compareTo( Card card )
    {
        return card.getScore() - getScore();
    }

    @Override
    public String toString()
    {
        return getFace();
    }

    /***Getters and Setters***/

    public String getFace()
    {
        return face;
    }

    private void setFace( String face )
    {
        this.face = face;
    }

    public int getId()
    {
        return id;
    }

    private void setId( int id )
    {
        this.id = id;
    }

    public int getSuit()
    {
        return suit;
    }

    private void setSuit( int suit )
    {
        this.suit = suit;
    }

    public int getNumber()
    {
        return number;
    }

    private void setNumber( int number )
    {
        this.number = number;
    }
}
