package Domain;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Pot
{
    private int total;
    private int currentBet;
    private int blind;
    private int buyIn;

    private Map<Player, Integer> playersAndBet;
    private Map<Player, Integer> playersAndMax;

    public Pot()
    {
        setTotal( 0 );
        setCurrentBet( 0 );
        setBlind( 0 );
        playersAndBet = new HashMap<>();
        playersAndMax = new HashMap<>();
    }

    public boolean hasMatched( Player player )
    {
        return hasBet( player ) && ( getBetFromPlayer( player ) == getCurrentBet() || player.isAllIn() );
    }

    public boolean hasBet( Player player )
   	{
        return playersAndBet.containsKey( player );
   	}

    public int getBetFromPlayer( Player player )
   	{
        int result = 0;
        if ( hasBet( player ) )
        {
            result = playersAndBet.get( player );
        }
   		return result;
   	}

    public void setBetFromPlayer( Player player, int bet )
   	{
        playersAndBet.put( player, bet );
   	}

    private int getRoundMax( int playerBet )
    {
        int result = 0;
        for ( Map.Entry<Player, Integer> playerAndBet : this.playersAndBet.entrySet() )
        {
            if ( playerBet <= playerAndBet.getValue() )
            {
                result += playerBet;
            }
            else
            {
                result += playerAndBet.getValue();
            }
        }
        return result;
    }

   	public void divvy( List<Player> players )
   	{
        if ( players.size() == 1 )
        {
            Player player = players.get( 0 );
            if ( playersAndMax.containsKey( player ) )
            {
                player.add( playersAndMax.get( player ) );
                subtract( playersAndMax.get( player ) );
            }
            else
            {
                player.add( getTotal() );
                subtract( getTotal() );
            }
        }
        else
        {
            List<Player> playersWithoutMax = new ArrayList<>();
            int dividedTotal = getTotal() / players.size();
            for ( Player player : players )
            {
                if ( playersAndMax.containsKey( player ) )
                {
                    int maxWinnings = dividedTotal > playersAndMax.get( player ) ? playersAndMax.get( player ) : dividedTotal;
                    player.add( maxWinnings );
                    subtract( maxWinnings );
                }
                else
                {
                    player.add( dividedTotal );
                    subtract( dividedTotal );
                    playersWithoutMax.add( player );
                }
            }

            if ( getTotal() > 0 && playersWithoutMax.size() > 0 )
            {
                dividedTotal = getTotal() / playersWithoutMax.size();
                for ( Player player : playersWithoutMax )
                {
                    player.add( dividedTotal );
                    subtract( dividedTotal );
                }

                playersWithoutMax.get( 0 ).add( getTotal() );
                subtract( getTotal() );
            }
        }
   	}

   	public void endRound()
   	{
        int originalTotal = getTotal();
        for ( Map.Entry<Player, Integer> playerAndBet : this.playersAndBet.entrySet() )
        {
            add( playerAndBet.getValue() );
            if ( playerAndBet.getValue() < getCurrentBet() )
            {
                playersAndMax.put( playerAndBet.getKey(), getRoundMax( playerAndBet.getValue() ) + originalTotal );
            }
        }
        playersAndBet.clear();
        setCurrentBet( 0 );
   	}

    public void endHand()
   	{
        incrementBlind();
        setCurrentBet( getBlind() );
        setTotal( 0 );
   		playersAndMax.clear();
   	}

    public void incrementBlind()
   	{
        int increasedBlind = getBlind() + getSmallBlind(); //Blind increments by 50% and rounds
        int multiple;
        if ( increasedBlind > getBuyIn() )
        {
            multiple = (int) ( getBuyIn() * .5 );
        }
        else if ( increasedBlind > 1000 )
        {
            multiple = 400;
        }
        else if ( increasedBlind > 200 )
        {
            multiple = 100;
        }
        else if ( increasedBlind > 100 )
        {
            multiple = 50;
        }
        else if ( increasedBlind > 20 )
        {
            multiple = 10;
        }
        else
        {
            multiple = 1;
        }
        increasedBlind = Math.round( increasedBlind / multiple ) * multiple;
        setBlind( increasedBlind );
   	}

    public void setInitialBlind()
    {
        int initialBlind = (int)( getBuyIn() * .02 );
        initialBlind = ( initialBlind % 2 == 0 ) ? initialBlind : initialBlind - 1;
        initialBlind = ( initialBlind < 2 ) ? 2 : initialBlind;
        setBlind( initialBlind );
    }

    public int getSmallBlind()
    {
        return getBlind() / 2;
    }

    public void subtract( int amount )
    {
        setTotal( getTotal() - amount );
    }

    public void add( int amount )
    {
        setTotal( getTotal() + amount );
    }

    /***Getters and Setters***/

    public int getTotal()
    {
        return total;
    }

    public void setTotal( int total )
    {
        this.total = total;
    }

    public int getCurrentBet()
    {
        return currentBet;
    }

    public void setCurrentBet( int currentBet )
    {
        this.currentBet = currentBet;
    }

    public int getBlind()
    {
        return blind;
    }

    public void setBlind( int blind )
    {
        this.blind = blind;
    }

    public int getBuyIn()
    {
        return buyIn;
    }

    public void setBuyIn( int buyIn )
    {
        this.buyIn = buyIn;
    }
}
