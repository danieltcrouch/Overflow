package Domain;

import java.util.ArrayList;
import java.util.List;

public class Player
{
    private List<Card> hand;
    private String name;

    private int index;
    private int money;
    private Action action;

    private boolean bluffing;
    private boolean ai;

    public Player()
    {
        setMoney( 1000 );
        setIndex( 0 );

        setHand( new Card(), new Card() );
        setName( "Player" + ( getIndex() + 1 ) );

        setAi( true );
    }

    public Player( int index )
    {
        this();
        setIndex( index );
        setName( "Player" + ( getIndex() + 1 ) );
    }

    public Player( int index, int money )
    {
        this( index );
        setMoney( money );
    }
    public enum ActionType
    {
        check,
        call,
        raise,
        fold;

        public static ActionType getActionFromChar( char c )
        {
            ActionType result;
            switch ( c )
            {
            case 'C':
                result = call;
                break;
            case 'R':
                result = raise;
                break;
            case 'F':
                result = fold;
                break;
            default:
                result = null;
            }
            return result;
        }
    }

    public static class Action
    {
        private ActionType actionType;
        private int amount;

        public Action( ActionType actionType )
        {
            setActionType( actionType );
        }

        public boolean isFolded()
        {
            return getActionType() != null && getActionType() == ActionType.fold;
        }

        public boolean isCall()
        {
            return getActionType() != null && ( getActionType() == ActionType.check || getActionType() == ActionType.call );
        }

        public ActionType getActionType()
        {
            return actionType;
        }

        public void setActionType( ActionType actionType )
        {
            this.actionType = actionType;
        }

        public int getAmount()
        {
            return amount;
        }

        public void setAmount( int amount )
        {
            this.amount = amount;
        }
    }

    public void subtract( int money )
    {
        setMoney( getMoney() - money );
    }

    public void add( int money )
    {
        setMoney( getMoney() + money );
    }

    public boolean isFolded()
    {
        return getAction() != null && getAction().isFolded();
    }

    public boolean isCall()
    {
        return getAction() != null && getAction().isCall();
    }

    public boolean hasActed()
    {
        return getAction() != null;
    }

    public boolean isAllIn()
    {
        return getMoney() == 0;
    }

    /***Getters and Setters***/

    public int getIndex()
    {
        return index;
    }

    public void setIndex( int index )
    {
        this.index = index;
    }

    public int getMoney()
    {
        return money;
    }

    public void setMoney( int money )
    {
        this.money = money;
    }

    public Action getAction()
    {
        return action;
    }

    public void setAction( Action action )
    {
        this.action = action;
    }

    public boolean isBluffing()
    {
        return bluffing;
    }

    public void setBluffing( boolean bluffing )
    {
        this.bluffing = bluffing;
    }

    public boolean isAi()
    {
        return ai;
    }

    public void setAi( boolean ai )
    {
        this.ai = ai;
    }

    public String getName()
    {
        return name;
    }

    public void setName( String name )
    {
        this.name = name;
    }

    public List<Card> getHand()
    {
        return hand;
    }

    public void setHand( List<Card> hand )
    {
        this.hand = hand;
    }

    public void setHand( Card c1, Card c2 )
    {
        hand = new ArrayList<>();
        hand.add( c1 );
        hand.add( c2 );
    }
}
