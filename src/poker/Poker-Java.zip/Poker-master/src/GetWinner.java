import Domain.Card;
import Domain.Player;
import IO.GameIO;
import IO.SetupIO;
import IO.UserIO;
import Service.Odds;
import Service.PokerService;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class GetWinner
{
    public static void getWinner()
    {
        List<Player> players = new ArrayList<>();
        int playerCount = SetupIO.getPlayerCount();
        System.out.println();
        for ( int i = 0; i < playerCount; i++ )
        {
            Player player = new Player( i );
            player.setHand( UserIO.getPlayerCards( player.getName() ) );
            players.add( player );
        }

        List<Card> community = UserIO.getCommunityCards();


        Map<Player, PokerService.WinType> winnersAndTypes = PokerService.getWinners( players, community );
        GameIO.printWinners( winnersAndTypes );
    }
}