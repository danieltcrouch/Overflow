import Domain.Card;
import Domain.Player;
import IO.SetupIO;
import IO.UserIO;
import Service.Odds;
import Service.PokerService;

import java.util.List;

public abstract class GetOdds
{
    public static void getOdds()
    {
        boolean isImplied = UserIO.getOddsType();
        int playerCount = SetupIO.getPlayerCount();
        List<Card> cards = UserIO.getCards();

        if ( cards.size() >= PokerService.PLAY_CARDS )
        {
            Player tempPlayer = new Player();
            tempPlayer.setHand( cards.get( 0 ), cards.get( 1 ) );

            cards.removeAll( tempPlayer.getHand() ); //community

            UserIO.printOdds( isImplied ? Odds.getImpliedOdds( tempPlayer.getHand(), cards, playerCount ) :
                              Odds.getOdds( tempPlayer.getHand(), cards, playerCount ) );
        }
    }
}