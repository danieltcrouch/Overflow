package Service;

import Domain.Card;
import Domain.Player;
import Domain.Pot;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;

public abstract class AI
{
    public static final double FOLD_ODDS = .3;
    public static final double RAISE_ODDS = .7;
    public static final double GOOD_ODDS = .90;
    public static final double NUT_ODDS = .98;
    public static final double WINNING_ODDS = .5;

    private static final double FEAR_MULTIPLIER = .6;

    public static final double FIVE_PERCENT = .05;
    public static final Random RANDOM = new Random();

    private static boolean strategicAI = false;
    private static Map<Player, Double> bluffers = new HashMap<>();

    public static Player.Action getAction( Player player, List<Player> players, List<Card> community, Pot pot, int handCount )
    {
        Player.Action result = new Player.Action( Player.ActionType.fold );
        double odds = Odds.getImpliedOdds( player.getHand(), community, players.size() );

        if ( !shouldFold( player, pot, getRaisers( players, pot, pot.getBetFromPlayer( player ) ), handCount, odds ) )
        {
            Player.Action raise = getRaiseAction( odds, player, players, pot );
            if ( raise.getActionType() != null && raise.getAmount() > pot.getCurrentBet() )
            {
                result = raise;
            }
            else if ( pot.hasMatched( player ) || pot.getCurrentBet() == 0 )
            {
                result.setActionType( Player.ActionType.check );
                result.setAmount( 0 );
            }
            else
            {
                result.setActionType( Player.ActionType.call );
                result.setAmount( pot.getCurrentBet() );
            }
        }

        result.setAmount( (int)getMax( result.getAmount(), player.getMoney() + pot.getBetFromPlayer( player ) ) );
        return result;
    }

    private static List<Player> getRaisers( List<Player> players, Pot pot, int playerBet )
    {
        return players.stream()
                .filter( pot::hasMatched )
                .filter( player -> pot.getBetFromPlayer( player ) > playerBet )
                .collect( Collectors.toList() );
    }

    private static boolean shouldFold( Player player, Pot pot, List<Player> raisers, int handCount, double odds )
    {
        boolean result = false;
        if ( !pot.hasMatched( player ) && pot.getCurrentBet() != 0 )
        {
            //This formula makes the AI more likely to fold to a high bet
            // More sensitive to increase in bet near Big blind and less so the closer it gets to all-in
            double betOverTotalMoney = getMax( (double)pot.getCurrentBet() / player.getMoney(), 1.0 );
            double betFear = getFearMultiplier( raisers, handCount, player.isBluffing() ) * Math.sqrt( 1.0 - Math.pow( 1.0 - betOverTotalMoney, 2.0 ) );
            if ( ( odds - betFear ) < FOLD_ODDS )
            {
                result = true;
            }
        }
        return result;
    }

    private static double getFearMultiplier( List<Player> raisers, int handCount, boolean isPlayerBluffing )
    {
        double result = FEAR_MULTIPLIER;
        //Don't consider bluffing if StrategicAI is not On
        if ( isStrategicAI() && ( raisers.stream().anyMatch( player -> isPlayerKnownBluffer( player, handCount ) ) || isPlayerBluffing ) )
        {
            result /= 2.0;
        }
        return result;
    }

    private static boolean isPlayerKnownBluffer( Player player, int handCount )
    {
        return bluffers.getOrDefault( player, 0.0 ) > ( handCount * FIVE_PERCENT ) && handCount > 3;
    }

    private static Player.Action getRaiseAction( double odds, Player player, List<Player> players, Pot pot )
    {
        Player.Action result = new Player.Action( null );

        if ( players.size() > 1 )
        {
            //Extra chance of "bluffing" for exceptionally good hands
            //Also, if StrategicAI is not On, use "bluffing" so Linear betting is used
            if ( ( odds >= NUT_ODDS && RANDOM.nextDouble() < FIVE_PERCENT ) ||
                 isStrategicAI() )
            {
                player.setBluffing( true );
            }

            int totalMoney = player.getMoney() + pot.getBetFromPlayer( player );
            double adjustedOdds = translatePercentile( 1.0 - RAISE_ODDS, odds - RAISE_ODDS );
            int curbedRaiseAmount = getCurbedRaiseAmount( players, totalMoney, pot.getBlind(), adjustedOdds );
            int linearRaiseAmount = getLinearRaiseAmount( totalMoney, pot.getBlind(), ( odds > GOOD_ODDS ) ? odds : 1 - odds );
            if ( player.isBluffing() && pot.getCurrentBet() < linearRaiseAmount )
            {
                result.setActionType( Player.ActionType.raise );
                result.setAmount( linearRaiseAmount );
            }
            else if ( odds > RAISE_ODDS && pot.getCurrentBet() < curbedRaiseAmount )
            {
                result.setActionType( Player.ActionType.raise );
                result.setAmount( curbedRaiseAmount );
            }
        }

        result.setAmount( getMaxRaise( getMinRaise( pot, result.getAmount() ), players ) );
        return result;
    }

    private static double translatePercentile( double max, double value )
    {
        return value * ( 1.0 / max ); //translates a value between 0 and max to between 0 and 1
    }

    private static int getLinearRaiseAmount( int totalMoney, int bigBlind, double odds )
    {
        return (int) ( ( ( totalMoney - bigBlind ) * odds ) + bigBlind );
    }

    private static int getCurbedRaiseAmount( List<Player> players, int totalMoney, int bigBlind, double odds )
    {
        int maxRaise = totalMoney / 10;
        int result = (int) ( maxRaise * Math.sin( 2.5 * odds ) + bigBlind );

        Player poorPlayer = getPlayerBelowMax( result * 1.2, players ); //Increase amount if within 20% of player's total money
        if ( poorPlayer != null && poorPlayer.getMoney() > result )
        {
            result = poorPlayer.getMoney();
        }

        return result;
    }

    private static int getMinRaise( Pot pot, int raise )
    {
        int result = raise;
        int doubleBlind = pot.getBlind() * 2;
        if ( raise < doubleBlind )
        {
            result = doubleBlind;
        }
        if ( raise < pot.getCurrentBet() )
        {
            result += 1;
        }
        return result;
    }

    private static int getMaxRaise( int raise, List<Player> players )
    {
        int richestPlayerMoney = getPlayerBelowMax( Integer.MAX_VALUE, players ).getMoney();
        return (int)getMax( raise, richestPlayerMoney );
    }

    private static double getMax( double value, double max )
    {
        return ( value > max ) ? max : value;
    }

    private static Player getPlayerBelowMax( double threshold, List<Player> players )
    {
        return players.stream()
                .filter( player -> player.getMoney() <= threshold )
                .sorted( ( player1, player2 ) -> Integer.compare( player1.getMoney(), player2.getMoney() ) )
                .findFirst()
                .orElse( null );
    }

    public static boolean shouldBluff( double odds )
    {
        //At the beginning of a round, randomly decide to bluff
        boolean result = false;

        if ( ( odds > FOLD_ODDS && odds < RAISE_ODDS ) && RANDOM.nextDouble() < FIVE_PERCENT )
        {
            result = true;
        }

        return result;
    }

    public static void checkForBluffing( List<Player> finalPlayers, List<Card> community )
    {
        if ( finalPlayers.size() > 1 ) //give half point for hidden win
        {
            finalPlayers.stream().filter( player -> Odds.getOdds( player.getHand(), community, finalPlayers.size() ) < WINNING_ODDS )
                    .forEach( AI::addBluff );
        }
        else
        {
            addHalfBluff( finalPlayers.get( 0 ) );
        }
    }

    public static void addBluff( Player player )
    {
        bluffers.put( player, bluffers.getOrDefault( player, 0.0 ) + 1 );
    }

    private static void addHalfBluff( Player player )
    {
        bluffers.put( player, bluffers.getOrDefault( player, 0.0 ) + 0.5 );
    }

    public static boolean isStrategicAI()
    {
        return strategicAI;
    }

    public static void setStrategicAI( boolean strategicAI )
    {
        AI.strategicAI = strategicAI;
    }
}
