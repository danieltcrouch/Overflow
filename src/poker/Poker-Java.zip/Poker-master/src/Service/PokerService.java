package Service;

import Domain.Card;
import Domain.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PokerService
{
    public static final int PLAY_CARDS = 2;
    public static final int COMM_CARDS = 5;
    public static final int ALL_CARDS = 7;

    public static final int BLIND_ROUND = 0;
    public static final int FLOP_ROUND = 1;
    public static final int TURN_ROUND = 2;
    public static final int RIVER_ROUND = 3;

    public static Map<Player, WinType> getWinners( List<Player> players, List<Card> community )
    {
        Map<Player, WinType> winnersAndTypes = new HashMap<>();
        int maxScore = 0;
        for ( Player player : players )
        {
            List<Card> playerCards = new ArrayList<>( player.getHand() );
            playerCards.addAll( community );
            int score = Scoring.getScore( playerCards );
            if ( score == maxScore )
            {
                winnersAndTypes.put( player, WinType.getFromScore( score ) );
            }
            else if ( score > maxScore )
            {
                winnersAndTypes.clear();
                winnersAndTypes.put( player, WinType.getFromScore( score ) );
                maxScore = score;
            }
        }

        return winnersAndTypes;
    }

    public enum WinType
    {
        fold( "Default", -1 ),
        highCard( "High Card", 0 ),
        pair( "Pair", 400000 ),
        twoPair( "Two Pair", 450000 ),
        threeOfAKind( "Three of a Kind", 455000 ),
        straight( "Straight", 455100 ),
        flush( "Flush", 455200 ),
        fullHouse( "Full House", 855300 ),
        fourOfAKind( "Four of a Kind", 855400 ),
        straightFlush( "Straight Flush", 855500 );

        private String name;
        private int score;

        WinType( String name, int score )
        {
            this.name = name;
            this.score = score;
        }

        public static WinType getFromScore( int score )
        {
            WinType result = null;
            for ( WinType type : getOrdered() )
            {
                if ( score >= type.getScore() )
                {
                    result = type;
                    break;
                }
            }

            return result;
        }

        public static List<WinType> getOrdered()
        {
            List<WinType> orderedList = Arrays.asList( values() );
            orderedList.sort( Comparator.comparing( WinType::getScore ).reversed() );
            return orderedList;
        }

        public String getName()
        {
            return name;
        }

        public int getScore()
        {
            return score;
        }
    }
}
