package Service;

import Domain.Card;
import Service.PokerService.WinType;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public abstract class Scoring
{
    public static int getScore( List<Card> all )
    {
        int score = 0;
        int temp;

        List<List<Card>> allCombos = Combinations.getCombos( all, PokerService.COMM_CARDS );

        for ( List<Card> combo : allCombos )
        {
            temp = calculateScore( combo );
            if ( temp > score )
            {
                score = temp;
            }
        }

        return score;
    }

    private static int calculateScore( List<Card> hand )
    {
        int score;
        Collections.sort( hand ); //In order: A, K, Q ...

        if ( hasStraightFlush( hand ) )
        {
            score = WinType.straightFlush.getScore() + getHighCard( hand ).getScore();
        }
        else if ( hasFour( hand ) )
        {
            score = WinType.fourOfAKind.getScore() + getFourNumber( hand );
        }
        else if ( hasFullHouse( hand ) )
        {
            int threeNumber = getThreeNumber( hand );
            score = WinType.fullHouse.getScore() + threeNumber * Card.NUM_COUNT + getPairNumber( removeDuplicates( hand, threeNumber ) );
        }
        else if ( hasFlush( hand ) )
        {
            score = WinType.flush.getScore() + getHighScore( hand );
        }
        else if ( hasStraight( hand ) )
        {
            score = WinType.straight.getScore() + getHighCard( hand ).getScore();
        }
        else if ( hasThree( hand ) )
        {
            int threeNumber = getThreeNumber( hand );
            score = WinType.threeOfAKind.getScore() + threeNumber + getHighScore( removeDuplicates( hand, threeNumber ) );
        }
        else if ( hasTwoPair( hand ) )
        {
            int higherPair = getPairNumber( hand );
            int lowerPair = getPairNumber( removeDuplicates( hand, higherPair ) );
            int fifthCard = removeDuplicates( removeDuplicates( hand, higherPair ), lowerPair ).get( 0 ).getScore();
            score = WinType.twoPair.getScore() + higherPair * (int) Math.pow( Card.NUM_COUNT, 2 ) + lowerPair * Card.NUM_COUNT + fifthCard;
        }
        else if ( hasPair( hand ) )
        {
            final int pairMultiplier = 3000;
            int pairNumber = getPairNumber( hand );
            score = WinType.pair.getScore() + pairMultiplier * pairNumber + getHighScore( removeDuplicates( hand, pairNumber ) );
        }
        else
        {
            score = getHighScore( hand );
        }

        return score;
    }

    private static Card getHighCard( List<Card> hand )
    {
        return hand.get( 0 );
    }

    private static int getHighScore( List<Card> hand )
    {
        int score = 0;
        for ( int i = 0; i < hand.size(); i++ )
        {
            score += hand.get( i ).getScore() * Math.pow( Card.NUM_COUNT, hand.size() - i - 1 );
        }
        return score;
    }

    /***Determine WinType***/

    private static boolean hasPair( List<Card> hand )
    {
        return hasDuplicates( hand, 2 );
    }

    private static boolean hasTwoPair( List<Card> hand )
    {
        return hasPair( removeDuplicates( hand, getPairNumber( hand ) ) );
    }

    private static boolean hasThree( List<Card> hand )
    {
        return hasDuplicates( hand, 3 );
    }

    private static boolean hasFour( List<Card> hand )
    {
        return hasDuplicates( hand, 4 );
    }

    private static boolean hasFullHouse( List<Card> hand )
    {
        return hasTwoPair( hand ) && hasThree( hand );
    }

    private static boolean hasFlush( List<Card> hand )
    {
        return hand.size() == PokerService.COMM_CARDS && hand.stream().allMatch( card -> card.isSuiteEqual( hand.get( 0 ) ) );
    }

    public static boolean hasStraight( List<Card> hand )
    {
        boolean result = false;
        if ( hand.size() == PokerService.COMM_CARDS &&
             ( hand.get( 0 ).getScore() == hand.get( 1 ).getNumber() + 1 && //For Ace High and all others
               hand.get( 0 ).getScore() == hand.get( 2 ).getNumber() + 2 &&
               hand.get( 0 ).getScore() == hand.get( 3 ).getNumber() + 3 &&
               hand.get( 0 ).getScore() == hand.get( 4 ).getNumber() + 4 ) ||
             ( hand.get( 1 ).getNumber() == hand.get( 2 ).getNumber() + 1 && //For Ace Low
               hand.get( 1 ).getNumber() == hand.get( 3 ).getNumber() + 2 &&
               hand.get( 1 ).getNumber() == hand.get( 4 ).getNumber() + 3 &&
               hand.get( 1 ).getNumber() == hand.get( 0 ).getNumber() + 4 ) )
        {
            result = true;
        }
        return result;
    }

    private static boolean hasStraightFlush( List<Card> hand )
    {
        return hasStraight( hand ) && hasFlush( hand );
    }

    /***Helper***/

    private static int getPairNumber( List<Card> hand )
    {
        int cardNumber = Card.BLANK;
        for ( int i = 1; i < hand.size(); i++ )
        {
            if ( hand.get( i ).isNumberEqual( hand.get( i - 1 ) ) )
            {
                cardNumber = hand.get( i ).getNumber();
                break;
            }
        }
        return cardNumber;
    }

    private static int getThreeNumber( List<Card> hand )
    {
        return hand.get( 2 ).getNumber(); //Assumes 5 or less cards with at least Three of a Kind
    }

    private static int getFourNumber( List<Card> hand )
    {
        return hand.get( 2 ).getNumber(); //Assumes 5 or less cards with at least Four of a Kind
    }

    private static List<Card> removeDuplicates( List<Card> hand, int number )
    {
        return hand.stream().filter( card -> card.getNumber() != number ).collect( Collectors.toList() );
    }

    private static boolean hasDuplicates( List<Card> hand, int count )
    {
        //numberAndMatches could be returned for more powerful analysis of hand
        Map<Integer, Integer> numberAndMatches = new HashMap<>();
        for ( int i = 1; i < hand.size(); i++ )
        {
            if ( hand.get( i ).isNumberEqual( hand.get( i - 1 ) ) )
            {
                numberAndMatches.merge( hand.get( i ).getNumber(), 1, (oldValue, one) -> oldValue + one );
            }
        }
        return numberAndMatches.values().stream().anyMatch( matches -> matches >= count - 1 );
    }
}
