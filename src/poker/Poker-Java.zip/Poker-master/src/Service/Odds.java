package Service;

import Domain.Card;
import Domain.Player;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public abstract class Odds
{
    public static double getOdds( List<Card> hand, List<Card> community, int playerCount )
    {
        double result;

        if ( community.isEmpty() )
        {
            result = lookupOdds( hand, playerCount );
        }
        else
        {
            result = assessOdds( hand, community, playerCount );
        }

        return result;
    }
    public static double getImpliedOdds( List<Card> hand, List<Card> community, int playerCount )
    {
        double result;

        if ( community.isEmpty() )
        {
            result = lookupOdds( hand, playerCount );
        }
        else
        {
            result = assessImpliedOdds( hand, community, playerCount );
        }

        return result;
    }

    private static double lookupOdds( List<Card> hand, int playerCount )
    {
        double result = 0;
        Card card1 = hand.get( 0 );
        Card card2 = hand.get( 1 );

        try
        {
            Scanner file = new Scanner( new File( "../Resources/two_card.txt" ) );
            file.useDelimiter( ",|\\n" );
            int count;

            while ( file.hasNext() )
            {
                List<Card> pair = new ArrayList<Card>();
                pair.add( new Domain.Card( file.next() ) );
                pair.add( new Domain.Card( file.next() ) );
                count = file.nextInt();
                result = file.nextDouble();

                if ( playerCount == count )
                {
                    if ( pair.contains( card1 ) && pair.contains( card2 ) )
                    {
                        result /= 100;
                        break;
                    }
                }
            }

            file.close();
        }
        catch ( Exception e )
        {
            int cardAverage = ( card1.getScore() + card2.getScore() ) / 2;
            result = (double) cardAverage / Card.NUM_COUNT;
        }

        return result;
    }

    private static double assessImpliedOdds( List<Card> hand, List<Card> community, int playerCount )
    {
        double result;
        if ( community.size() > 3 )
        {
            List<Card> playerCards = new ArrayList<>( hand );
            playerCards.addAll( community );
            List<List<Card>> communityPossibilities = new ArrayList<>();
            Domain.Deck deck = new Domain.Deck();
            if ( community.size() != PokerService.COMM_CARDS )
            {
                for ( List<Card> additionalCommunityCards : Combinations.getCombos( deck.getCards(), PokerService.COMM_CARDS - community.size(), playerCards ) )
                {
                    List<Card> tempCommunity = new ArrayList<>( community );
                    tempCommunity.addAll( additionalCommunityCards );
                    communityPossibilities.add( tempCommunity );
                }
            }
            else
            {
                communityPossibilities.add( community );
            }

            List<Double> odds = new ArrayList<>();
            communityPossibilities.stream().forEach( tempCommunity -> odds.add( assessOdds( hand, tempCommunity, playerCount ) ) );
            result = odds.stream().mapToDouble( x -> x ).summaryStatistics().getAverage();
        }
        else
        {
            result = assessOdds( hand, community, playerCount );
        }
        return result;
    }

    private static double assessOdds( List<Card> hand, List<Card> community, int playerCount )
    {
        double result;

        int win = 0;
        int tie = 0;
        int lose = 0;

        List<Card> playerCards = new ArrayList<>( hand );
        playerCards.addAll( community );
        int score = Scoring.getScore( playerCards );

        Domain.Deck deck = new Domain.Deck();
        for ( List<Card> potentialHand : Combinations.getCombos( deck.getCards(), PokerService.PLAY_CARDS, playerCards ) )
        {
            List<Card> opponentCards = new ArrayList<>( potentialHand );
            opponentCards.addAll( community );
            int opponentScore = Scoring.getScore( opponentCards );
            if ( score > opponentScore )
            {
                win++;
            }
            else if ( score == opponentScore )
            {
                tie++;
            }
            else
            {
                lose++;
            }
        }

        double odds = ( win + (double) tie / 2 ) / ( win + tie + lose );
        result = Math.pow( odds, playerCount - 1 );
        return result;
    }
}
