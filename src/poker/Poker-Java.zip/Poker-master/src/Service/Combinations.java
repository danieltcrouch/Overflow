package Service;

import Domain.Card;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Stack;

public abstract class Combinations
{
    public static List<List<Card>> getCombos( List<Card> cards, int count, List<Card> ignoreCards )
    {
        List<Card> temp = new ArrayList<>( cards );
        temp.removeAll( ignoreCards );
        return getCombos( temp, count );
    }

    public static List<List<Card>> getCombos( List<Card> cards, int count )
    {
        List<List<Card>> combos = new ArrayList<>();
        List<Card> combo = new ArrayList<>( Collections.nCopies( count, Card.getBlank() ) );

        Stack<Integer> stack = new Stack<>();
        stack.push( 0 );

        while ( stack.size() > 0 )
        {
            int index = stack.size() - 1;
            int valueIndex = stack.pop();

            while ( valueIndex < cards.size() )
            {
                combo.set( index++, cards.get( valueIndex++ ) );
                stack.push( valueIndex );

                if ( index == count )
                {
                    combos.add( combo );
                    List<Card> temp = new ArrayList<>();
                    for ( int i = 0; i < count; i++ )
                    {
                        temp.add( new Card( combo.get( i ) ) );
                    }
                    combo = temp;
                    break;
                }
            }
        }

        return combos;
    }
}
