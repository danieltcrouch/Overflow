package IO;

import Domain.Card;
import Domain.Player;
import Domain.Pot;
import Service.PokerService;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public abstract class UserIO
{
    private static Scanner key = new Scanner( System.in );

    public static Player.ActionType getAction( Player player, int currentBet )
    {
        System.out.println( "Actions: (C)heck, (C)all, (R)aise, (F)old" );
        printHandReminder( player.getHand() );
        char input = '0';
        do
        {
            System.out.print( "Enter an action: " );
            try
            {
                input = key.nextLine().toUpperCase().charAt( 0 );
            }
            catch ( Exception e ) {}
        } while ( !( input == 'C' || input == 'R' || input == 'F' ) ||
                   ( input == 'R' && player.getMoney() <= currentBet ) );

        return Player.ActionType.getActionFromChar( input );
    }

    public static int getRaiseAmount( Player player, Pot pot )
    {
        int input = 0;
        int min = pot.getCurrentBet() + 1;
        int max = player.getMoney() + pot.getBetFromPlayer( player );
        do
        {
            System.out.print( "Enter an amount to bet (" + min + "-" + max + "): " );
            try
            {
                input = Integer.parseInt( key.nextLine() );
            }
            catch ( Exception e ) {}
        } while ( input > max || input < min );

        return input;
    }

    public static void printHandFirst( List<Card> hand )
    {
        System.out.println( "You were dealt " + hand );
    }

    public static void printHandReminder( List<Card> hand )
    {
        System.out.println( "\tYou have " + hand );
    }

    /***Odds***/

    public static boolean getOddsType()
    {
        boolean isImplied = false;
        try
        {
            System.out.print( "Would you like to get Implied Odds, (Y)es or (N)o? " );
            char input = key.nextLine().toUpperCase().charAt( 0 );
            if ( input == 'Y' )
            {
                isImplied = true;
            }
        }
        catch ( Exception e ) {}

        return isImplied;
    }

    public static List<Card> getCards()
    {
        List<Card> result;
        do
        {
            result = new ArrayList<>();
            try
            {
                System.out.println();
                System.out.print( "Beginning with your own cards, enter 2, 5, 6, or 7 cards separated by a space: " );
                String cards = key.nextLine().trim();
                for ( String card : cards.split( "\\s+" ) )
                {
                    result.add( new Card( card ) );
                }
            }
            catch ( Exception e ) {}
        } while ( result.size() > PokerService.ALL_CARDS || result.size() < PokerService.PLAY_CARDS ||
                  result.size() == 3 || result.size() == 4 );

        return result;
    }

    public static void printOdds( double odds )
    {
        System.out.println( "Your odds are: " + odds );
        System.out.println( "**************\n" );
    }

    /***Winner***/

    public static List<Card> getPlayerCards( String name )
    {
        List<Card> result;
        do
        {
            result = new ArrayList<>();
            try
            {
                System.out.print( "Please enter 2 cards for " + name + " separated by a space: " );
                String cards = key.nextLine().trim();
                for ( String card : cards.split( "\\s+" ) )
                {
                    result.add( new Card( card ) );
                }
            }
            catch ( Exception e ) {}
        } while ( result.size() != PokerService.PLAY_CARDS );

        return result;
    }

    public static List<Card> getCommunityCards()
    {
        List<Card> result;
        do
        {
            result = new ArrayList<>();
            try
            {
                System.out.println();
                System.out.print( "Please enter 5 cards for the community separated by a space: " );
                String cards = key.nextLine().trim();
                for ( String card : cards.split( "\\s+" ) )
                {
                    result.add( new Card( card ) );
                }
            }
            catch ( Exception e ) {}
        } while ( result.size() > PokerService.COMM_CARDS );

        return result;
    }
}
