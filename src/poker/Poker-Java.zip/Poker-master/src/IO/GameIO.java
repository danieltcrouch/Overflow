package IO;

import Domain.Card;
import Domain.Player;
import Service.PokerService;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class GameIO
{
    public static void printGameIntro()
    {
        System.out.println( "\nYou are Player1" );
    }

    public static void printGameStatus( List<Player> players )
    {
        System.out.println( "***********************************" );
        for ( Player player : players )
        {
            System.out.print( player.getName() + ": $" + player.getMoney() );
            if ( !players.get( players.size() - 1 ).equals( player ) )
            {
                System.out.print( ", " );
            }
            else
            {
                System.out.println();
            }
        }
    }

    public static void printPlayerAction( Player player, int betAmount )
    {
        String action;
        switch ( player.getAction().getActionType() )
        {
        case raise:
            action = "Raised $" + betAmount;
            break;
        case call:
            action = "Called";
            break;
        case check:
            action = "Checked";
            break;
        case fold:
            action = "Folded";
            break;
        default:
            action = "Folded";
        }

        System.out.println( player.getName() + " " + action );
    }

    public static void printHands( List<Player> players )
    {
        System.out.println();
        for ( Player player : players )
        {
            printHand( player );
        }
    }

    public static void printHand( Player player )
    {
        System.out.println( player.getName() + " " + player.getHand() );
    }

    public static void printRound( List<Card> community )
    {
        System.out.println();
        if ( community.size() > 0 )
        {
            System.out.print( "The Community Cards are " );
            for ( Card card : community )
            {
                System.out.print( card );
                if ( !community.get( community.size() - 1 ).equals( card ) )
                {
                    System.out.print( ", " );
                }
                else
                {
                    System.out.println();
                }
            }
        }
    }

    public static void printWinners( Map<Player, PokerService.WinType> winnersAndTypes )
    {
        List<Player> winners = new ArrayList<>( winnersAndTypes.keySet() );
        for ( Player player : winners )
        {
            System.out.print( "Win: " + player.getName() + " by " + winnersAndTypes.get( player ).getName() );
            if ( player != winners.get( winners.size() - 1 ) )
            {
                System.out.print( ", " );
            }
        }
        System.out.println( "\n" );
    }

    public static void printFinalWinner( boolean winner )
    {
        if ( winner )
        {
            System.out.println( "**************" );
            System.out.println( "   You Won!" );
            System.out.println( "**************" );
        }
        else
        {
            System.out.println( "********************" );
            System.out.println( "  Sorry, you lost." );
            System.out.println( "********************" );
        }
        System.out.println( "\n" );
    }

    public static void printBlinds( int smallBlind, Player smallBlindPlayer, int bigBlind, Player bigBlindPlayer )
    {
        System.out.println( smallBlindPlayer.getName() + " bet blind of $"  + smallBlind );
        System.out.println( bigBlindPlayer.getName() + " bet blind of $"  + bigBlind );
        System.out.println();
    }
}
