package IO;

import java.util.Scanner;

public class SetupIO
{
    private static Scanner key = new Scanner( System.in );

    private static final int MAX_PLAYERS = 10;
    private static final int MAX_AMOUNT = 100000;
    private static final int MIN_AMOUNT = 50;

    public static void printRules()
    {
        System.out.println( "Cards are represented by two characters:\n" +
                            "The first letter of the suit (S,C,D,H)\n" +
                            "followed by the number (2-9,T,J,Q,K,A)\n" );
    }

    public static char getGameType()
    {
        char input = 'N';
        try
        {
            System.out.println( "Type 'X' to Quit. " );
            System.out.print( "Would you like to assess (O)dds, determine a hand (W)inner, play a (Q)uick Game, or play a (N)ormal Game? " );
            input = key.nextLine().toUpperCase().charAt( 0 );
        }
        catch( Exception e ) {}

        return input;
    }

    public static int getPlayerCount()
    {
        int input = 0;
        do
        {
            try
            {
                System.out.print( "Enter the number of players (2-10): " );
                input = Integer.parseInt( key.nextLine() );
            }
            catch( Exception e ) {}
        } while ( input > MAX_PLAYERS || input < 2 );

        return input;
    }

    public static int getStartingAmount()
    {
        int input = 0;
        do
        {
            try
            {
                System.out.print( "Enter the starting amount for each player (50-100000): " );
                input = Integer.parseInt( key.nextLine() );
            }
            catch ( Exception e ) {}
        } while ( input > MAX_AMOUNT || input < MIN_AMOUNT );

        return input;
    }

    public static String getPlayerName( String name )
    {
        String newName = null;
        try
        {
            System.out.print( "Enter a name for " + name + ": " );
            newName = key.nextLine().trim();
        }
        catch ( Exception e ) {}

        return ( "".equals( newName ) ) ? name : newName;
    }

    public static boolean getAiPersonality()
    {
        boolean result = false;
        try
        {
            System.out.print( "Would you like to play with AI strategy, (Y)es or (N)o? " );
            char input = key.nextLine().toUpperCase().charAt( 0 );
            if ( input == 'Y' )
            {
                result = true;
            }
        }
        catch ( Exception e ) {}

        return result;
    }

    public static int getDealerIndex( int playerCount )
    {
        int input = 0;
        do
        {
            try
            {
                System.out.print( "Enter the number of the player to begin as dealer (you are Player #1): " );
                input = Integer.parseInt( key.nextLine() );
            }
            catch ( NumberFormatException e ) {}
        } while ( input > playerCount || input < 1 );

        return input - 1;
    }
}
