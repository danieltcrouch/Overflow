import Domain.Card;
import Domain.Deck;
import Domain.Player;
import Domain.Pot;
import Service.AI;
import IO.GameIO;
import Service.Odds;
import Service.PokerService;
import IO.SetupIO;
import IO.UserIO;

import java.util.*;
import java.util.stream.Collectors;

public class AutoGame
{
    List<Player> players;
    Player user;
    Player dealer;
    Player smallBlindPlayer;
    Player bigBlindPlayer;

    Deck deck;
    Pot pot;
    List<Card> community;

    int roundCount;
    int handCount;

    public AutoGame()
    {
        this( true );
    }

    public AutoGame( boolean normalGame )
    {
        setPlayers( createPlayers( normalGame ) );
        setUser( getPlayers().get( 0 ) );

        int dealerIndex = 0;
        boolean strategicAi = true;
        if ( normalGame )
        {
            dealerIndex = SetupIO.getDealerIndex( getPlayers().size() );
            strategicAi = SetupIO.getAiPersonality();
        }
        updateDealer( dealerIndex );
        AI.setStrategicAI( strategicAi );

        setPot( new Pot() );
        setDeck( new Deck() );
        setCommunity( new ArrayList<>() );
        getPot().setBuyIn( getUser().getMoney() );
        getPot().setInitialBlind();
    }

    public void playGame()
    {
        GameIO.printGameIntro();

        do
        {
            GameIO.printGameStatus( getPlayers() );
            playHand();
        } while ( !isGameOver() );

        endGame();
    }

    private boolean isGameOver()
    {
        int playersWithMoney = (int) getPlayers().stream().filter( player -> player.getMoney() > 0 ).count();
        return playersWithMoney == 1 || getUser().getMoney() == 0;
    }

    private void endGame()
    {
        GameIO.printFinalWinner( getUser().getMoney() > 0 );
    }

    private void playHand()
    {
        getDeck().shuffle();
        dealHand();
        betBlind();

        for ( setRoundCount( PokerService.BLIND_ROUND ); !isHandOver(); incrementRoundCount() )
        {
            playRound();
        }

        endHand();
    }

    private void dealHand()
    {
        for ( Player player : getPlayers() )
        {
            player.setHand( getDeck().deal(), getDeck().deal() );
            player.setBluffing( AI.shouldBluff( Odds.getImpliedOdds( player.getHand(), getCommunity(), getPlayers().size() ) ) );
        }
        UserIO.printHandFirst( getUser().getHand() );
    }

    private boolean isHandOver()
    {
        return getRoundCount() > PokerService.RIVER_ROUND;
    }

    private void endHand()
    {
        resetRoundCount();
        payWinners();
        getPot().endHand();
        getCommunity().clear();
        clearPlayers();
        updateDealer();
        incrementHandCount();
    }

    private void playRound()
    {
        dealRound();

        if ( getActingPlayers().size() > 1 || isBlindRound() )
        {
            do
            {
                getActingPlayers().stream().forEach( this::performAction );
            } while ( !isRoundOver() );
        }

        endRound();
    }

    private void dealRound()
    {
        switch ( getRoundCount() )
        {
            case PokerService.RIVER_ROUND:
                getDeck().deal(); //burn
                getCommunity().add( getDeck().deal() );
                break;
            case PokerService.TURN_ROUND:
                getDeck().deal(); //burn
                getCommunity().add( getDeck().deal() );
                break;
            case PokerService.FLOP_ROUND:
                getDeck().deal(); //burn
                getCommunity().add( getDeck().deal() );
                getCommunity().add( getDeck().deal() );
                getCommunity().add( getDeck().deal() );
                break;
            case PokerService.BLIND_ROUND:
                break;
        }
        GameIO.printRound( getCommunity() );
    }

    private boolean isRoundOver()
    {
        return getActingPlayers().size() == 0;
    }

    private void endRound()
    {
        getNonFoldedPlayers().stream().forEach( player -> player.setAction( null ) );
        getPot().endRound();
    }

    /***Initialization***/

    private List<Player> createPlayers( boolean normalGame )
    {
        int playerCount = 3;
        int startingAmount = 1000;
        if ( normalGame )
        {
            playerCount = SetupIO.getPlayerCount();
            startingAmount = SetupIO.getStartingAmount();
        }

        List<Player> players = new ArrayList<>();
        for ( int i = 0; i < playerCount; i++ )
        {
            Player player = new Player( i, startingAmount );
            player.setAi( i > 0 );
            players.add( player );
            if ( normalGame )
            {
                player.setName( SetupIO.getPlayerName( player.getName() ) );
            }
        }

        return players;
    }

    /***Player Actions***/

    private boolean canAct( Player player )
    {
        boolean result = !( player.isAllIn() || ( getPot().hasMatched( player ) && player.hasActed() ) );

        boolean isBlindPlayer = player == getSmallBlindPlayer() || player == getBigBlindPlayer();
        if ( isBlindRound() && isBlindPlayer && getPlayers().size() > 2 )
        {
            result &= getDealer().hasActed();
        }

        return result;
    }

    private void performAction( Player player )
    {
        int betAmount;
        if ( player.isAi() )
        {
            player.setAction( AI.getAction( player, getNonFoldedPlayers(), getCommunity(), getPot(), getHandCount() ) );
            betAmount = player.getAction().getAmount();
            GameIO.printPlayerAction( player, betAmount );
        }
        else
        {
            player.setAction( new Player.Action( UserIO.getAction( player, getPot().getCurrentBet() ) ) );
            betAmount = player.isCall() || player.isFolded() ? getPot().getCurrentBet() : UserIO.getRaiseAmount( player, getPot() );
            betAmount = getMaxBet( player, betAmount );
            player.getAction().setAmount( betAmount );
        }

        if ( !player.isFolded() )
        {
            bet( player, betAmount );
        }
    }

    private void betBlind()
    {
        if ( isBlindRound() )
        {
            bet( getSmallBlindPlayer(), getMaxBet( getSmallBlindPlayer(), getPot().getSmallBlind() ) );
            bet( getBigBlindPlayer(), getMaxBet( getBigBlindPlayer(), getPot().getBlind() ) );
            GameIO.printBlinds( getPot().getSmallBlind(), getSmallBlindPlayer(), getPot().getBlind(), getBigBlindPlayer() );
        }
    }

    private void bet( Player player, int newBet )
    {
        int previousBet = getPot().getBetFromPlayer( player );
        if ( previousBet <= newBet )
        {
            int betDifference = newBet - previousBet;
            player.subtract( betDifference );
            getPot().setBetFromPlayer( player, newBet );

            if ( newBet > getPot().getCurrentBet() )
            {
                getPot().setCurrentBet( newBet );
            }
        }
    }

    public static int getMaxBet( Player player, int betAmount )
    {
        return ( betAmount <= player.getMoney() ) ? betAmount : player.getMoney();
    }

    /***New Hand***/

    private void payWinners()
    {
        //Split or side pot may result in multiple winners
        List<Player> playersToCheck = getNonFoldedPlayers();
        AI.checkForBluffing( playersToCheck, getCommunity() );
        if ( playersToCheck.size() > 1 )
        {
            GameIO.printHands( playersToCheck );
            do
            {
                Map<Player, PokerService.WinType> winnersAndTypes = PokerService.getWinners( playersToCheck, getCommunity() );
                List<Player> winners = new ArrayList<>( winnersAndTypes.keySet() );

                playersToCheck.removeAll( winners );
                getPot().divvy( winners );
                GameIO.printWinners( winnersAndTypes );
            } while ( getPot().getTotal() > 0 && playersToCheck.size() > 0 );
        }
        else
        {
            Map<Player, PokerService.WinType> winnerAndType = new HashMap<>();
            winnerAndType.put( playersToCheck.get( 0 ), PokerService.WinType.fold );
            getPot().divvy( new ArrayList<>( winnerAndType.keySet() ) );
            GameIO.printWinners( winnerAndType );
        }
    }

    private void clearPlayers()
    {
        List<Player> playersToRemove = new ArrayList<>();
        for ( Player player : getPlayers() )
        {
            player.setBluffing( false );
            player.setAction( null );
            player.setHand( null );
            if ( player.getMoney() == 0 )
            {
                playersToRemove.add( player );
            }
        }
        getPlayers().removeAll( playersToRemove );
    }

    private void updateDealer( int dealerIndex )
    {
        updateDealer();
        for ( int i = 0; i < dealerIndex; i++ )
        {
            updateDealer();
        }
    }

    private void updateDealer()
    {
        if ( !isGameOver() )
        {
            getPlayers().add( getPlayers().remove( 0 ) );

            setDealer( getPlayers().get( getPlayers().size() - 1 ) );
            setSmallBlindPlayer( getPlayers().get( 0 ) );
            setBigBlindPlayer( getPlayers().get( 1 ) );
        }
    }

    /***Helper***/

    private List<Player> getActingPlayers()
    {
        return getNonFoldedPlayers().stream()
                .filter( this::canAct )
                .collect( Collectors.toList() );
    }

    private List<Player> getNonFoldedPlayers()
    {
        return getPlayers().stream()
                .filter( player -> !player.isFolded() )
                .collect( Collectors.toList() );
    }

    private boolean isBlindRound()
    {
        return getRoundCount() == PokerService.BLIND_ROUND;
    }

    private void resetRoundCount()
    {
        setRoundCount( PokerService.BLIND_ROUND );
    }

    private void incrementRoundCount()
    {
        setRoundCount( getRoundCount() + 1 );
    }

    private void incrementHandCount()
    {
        setHandCount( getHandCount() + 1 );
    }

//    private void sleep()
//    {
//        try
//        {
//            TimeUnit.SECONDS.sleep( 1 );
//        }
//        catch ( Exception e )
//        {
//            //Do Nothing
//        }
//    }

    /***Getters and Setters***/

    private List<Player> getPlayers()
    {
        return players;
    }

    private void setPlayers( List<Player> players )
    {
        this.players = players;
    }

    public Player getUser()
    {
        return user;
    }

    private void setUser( Player user )
    {
        this.user = user;
    }

    public Player getDealer()
    {
        return dealer;
    }

    public void setDealer( Player dealer )
    {
        this.dealer = dealer;
    }

    public Player getSmallBlindPlayer()
    {
        return smallBlindPlayer;
    }

    public void setSmallBlindPlayer( Player smallBlindPlayer )
    {
        this.smallBlindPlayer = smallBlindPlayer;
    }

    public Player getBigBlindPlayer()
    {
        return bigBlindPlayer;
    }

    public void setBigBlindPlayer( Player bigBlindPlayer )
    {
        this.bigBlindPlayer = bigBlindPlayer;
    }

    public Deck getDeck()
    {
        return deck;
    }

    private void setDeck( Deck deck )
    {
        this.deck = deck;
    }

    public Pot getPot()
    {
        return pot;
    }

    private void setPot( Pot pot )
    {
        this.pot = pot;
    }

    public List<Card> getCommunity()
    {
        return community;
    }

    private void setCommunity( List<Card> community )
    {
        this.community = community;
    }

    public int getRoundCount()
    {
        return roundCount;
    }

    public void setRoundCount( int roundCount )
    {
        this.roundCount = roundCount;
    }

    public int getHandCount()
    {
        return handCount;
    }

    public void setHandCount( int handCount )
    {
        this.handCount = handCount;
    }
}