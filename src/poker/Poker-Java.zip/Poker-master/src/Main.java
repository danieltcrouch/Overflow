import IO.SetupIO;

public class Main
{
    public static void main( String[] args )
    {
        SetupIO.printRules();
        char choice;

        do
        {
            choice = SetupIO.getGameType();
            AutoGame game;
            switch ( choice )
            {
                case 'X':
                    break;
                case 'W':
                    GetWinner.getWinner();
                    break;
                case 'O':
                    GetOdds.getOdds();
                    break;
                case 'N':
                    game = new AutoGame();
                    game.playGame();
                    break;
                case 'Q':
                default:
                    game = new AutoGame( false );
                    game.playGame();
            }
        } while ( choice != 'X' );
    }
}